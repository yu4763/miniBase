package minibase;

import java.util.*;


/**
 * @param <K> Type of the Cache Key
 * @param <V> Type of the Cache Elements
 */
public class LruCache <K, V> {

	
	/**
	 * Constructor
	 * @param capacity
	 */
	public LruCache (int capacity) {
	  // TODO: some code goes here 
	}

	public boolean isCached(K key) {
	  // TODO: some code goes here 
	  return false;
	}

	public V get (K key) {
	  // TODO: some code goes here 
	  return null;
	}

	public void put (K key, V value) {
	  // TODO: some code goes here 
	}

	public V evict() {
	  // TODO: some code goes here 
	  return null;
	}

	public int size() {
	  // TODO: some code goes here 
	  return -1;
	}
	
	public Iterator<V> iterator() {
	  // TODO: some code goes here,,, please implement freely! you can remove and make new method 
	  return null;
	}


}
